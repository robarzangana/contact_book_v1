/*
Namn: Robar Zangana
Datum: 09/01/19
Kurs: Introduktion till programmering i C++
Labboration: Examination kontaktbok
*/
#ifndef METOD_H
#define METOD_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
//#include <limits>
//#include <iomanip>
//#include <cctype>
using namespace std;

int main();
void add();
void del();
void find();
string only_num_check();
string lower_check(string a);
string only_alpha_check();
string mail_check(string a);

#endif